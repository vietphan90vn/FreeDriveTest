using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//using Plugins;

namespace MapMagic
{
	[GeneratorMenu (menu="Output", name ="RTP", disengageable = true)]
	public partial class RTPOutput : Layout.ILayered
	{
		[System.NonSerialized] public static ReliefTerrain rtp;

		//layer
		public class Layer : Layout.ILayer
		{
			public Input input = new Input(InoutType.Map);
			public Output output = new Output(InoutType.Map);
			public string name = "Layer";
			public float opacity = 1;
			//public SplatPrototype splat = new SplatPrototype();
			//public Texture2D icon;
			public ReliefTerrain rtp = null;
			public int num = 0;


			public bool pinned { get; set; }
			public int guiHeight { get; set; }

			public void OnCollapsedGUI (Layout layout) 
			{
				layout.margin = 20; layout.rightMargin = 20; layout.fieldSize = 1f;
				layout.Par(40); 
				if (!pinned) input.DrawIcon(layout);
				
				//layout.Par(40); //not 65
				layout.Field(ref rtp.globalSettingsHolder.splats[num], rect:layout.Inset(40));
				layout.Label(rtp.globalSettingsHolder.splats[num].name + (pinned? "\n(Background)" : ""), rect:layout.Inset(layout.field.width-40));

				output.DrawIcon(layout);
			}

			public void OnExtendedGUI (Layout layout) 
			{

			}

			public void OnAdd (int n) { }
			public void OnRemove (int n) 
			{ 
				input.Link(null,null); 
				Input connectedInput = output.GetConnectedInput(MapMagic.instance.gens.list);
				if (connectedInput != null) connectedInput.Link(null, null);
			}
			public void OnSwitch (int o, int n) { }
		}
		public Layer[] baseLayers = new Layer[] { new Layer(){pinned=true, name="Background"}, new Layer(), new Layer(), new Layer() };
		public Layout.ILayer[] layers 
		{ 
			get {return baseLayers;} 
			set {baseLayers=ArrayTools.Convert<Layer,Layout.ILayer>(value);} 
		}

		public int selected { get; set; }
		public int collapsedHeight { get; set; }
		public int extendedHeight { get; set; }
		public Layout.ILayer def {get{ return new Layer(); }}
		
		public static Texture2D _defaultTex;
		public static Texture2D defaultTex {get{ if (_defaultTex==null) _defaultTex=Extensions.ColorTexture(2,2,new Color(0.5f, 0.5f, 0.5f, 0f)); return _defaultTex; }}

		public class RTPTuple { public int layer; public Color[] colorsA; public Color[] colorsB; public float opacity; }
		//public class RTPTuple { public int layer; public Matrix matrix; public Matrix biomeMask; public float opacity; }
		//public class RTPTuple { public float[,,] array; public SplatPrototype[] prototypes; public Matrix[] matrices; public Matrix[] biomeMasks;  }


		//generator
		public override IEnumerable<Input> Inputs() 
		{ 
			if (baseLayers==null) baseLayers = new Layer[0];
			for (int i=0; i<baseLayers.Length; i++) 
				if (baseLayers[i] != null && baseLayers[i].input != null)
					yield return baseLayers[i].input; 
		}
		public override IEnumerable<Output> Outputs() 
		{ 
			if (baseLayers==null) baseLayers = new Layer[0];
			for (int i=0; i<baseLayers.Length; i++) 
				if (baseLayers[i] != null && baseLayers[i].output != null)
					yield return baseLayers[i].output; 
		}

		public override void Generate (Chunk chunk, Biome biome=null)
		{
			if (chunk.stop || !enabled) return;
			
			//loading inputs
			Matrix[] matrices = new Matrix[baseLayers.Length];
			for (int i=0; i<baseLayers.Length; i++)
			{
				if (baseLayers[i].input != null) 
				{
					matrices[i] = (Matrix)baseLayers[i].input.GetObject(chunk);
					if (matrices[i] != null) matrices[i] = matrices[i].Copy(null);
				}
				if (matrices[i] == null) matrices[i] = chunk.defaultMatrix;
			}

			//background matrix
			//matrices[0] = terrain.defaultMatrix; //already created
			matrices[0].Fill(1);
			
			//populating opacity array
			float[] opacities = new float[matrices.Length];
			for (int i=0; i<baseLayers.Length; i++)
				opacities[i] = baseLayers[i].opacity;
			opacities[0] = 1;

			//multiplying on biomes masks
			/*if (biome != null)
			{
				Matrix biomeMask = (Matrix)biome.mask.GetObject(chunk);
				if (biomeMask != null) 
					for (int i=0; i<matrices.Length; i++) matrices[i].Multiply(biomeMask);
			}*/

			//blending layers
			Matrix.BlendLayers(matrices, opacities);

			//saving changed matrix results
			for (int i=0; i<baseLayers.Length; i++) 
			{
				if (chunk.stop) return; //do not write object is generating is stopped
				baseLayers[i].output.SetObject(chunk, matrices[i]);
			}
		}

		static partial void _Process (Chunk chunk)
		{
			if (chunk.stop) return;

			//debug timer
			if (MapMagic.instance.guiDebug)
			{
				if (chunk.timer==null) chunk.timer = new System.Diagnostics.Stopwatch(); 
				else chunk.timer.Reset();
				chunk.timer.Start();
			}

			//finding number of layers
			int layersCount = 0;
			foreach (RTPOutput gen in MapMagic.instance.gens.GeneratorsOfType<RTPOutput>(onlyEnabled:true, checkBiomes:true))
				layersCount += gen.baseLayers.Length;
			
			//creating color arrays
			RTPTuple result = new RTPTuple();
			result.colorsA = new Color[MapMagic.instance.resolution * MapMagic.instance.resolution];
			if (layersCount > 4) result.colorsB = new Color[MapMagic.instance.resolution * MapMagic.instance.resolution];
			
			//filling color arrays
			int layerNum = 0;
			int maxX = MapMagic.instance.resolution;
			int maxZ = MapMagic.instance.resolution;
			foreach (RTPOutput gen in MapMagic.instance.gens.GeneratorsOfType<RTPOutput>(onlyEnabled:true, checkBiomes:true))
			{
				//loading biome matrix
				Matrix biomeMask = null;
				if (gen.biome != null) 
				{
					biomeMask = gen.biome.mask.GetObject<Matrix>(chunk);
					if (biomeMask == null || biomeMask.IsEmpty()) continue;
				}

				for (int i=0; i<gen.baseLayers.Length; i++)
				{
					layerNum++;

					Matrix matrix = gen.baseLayers[i].output.GetObject<Matrix>(chunk);
					if (matrix == null) continue;

					for (int x=0; x<maxX; x++)
						for (int z=0; z<maxZ; z++)
					{
						int pos = matrix.rect.GetPos(x+matrix.rect.offset.x, z+matrix.rect.offset.z); //pos should be the same for colors array and matrix array
						
						//get value and adjust with biome mask
						float val = matrix.array[pos];
						float biomeVal = biomeMask!=null? biomeMask.array[pos] : 1;
						val *= biomeVal;

						//save value to colors array
						switch (layerNum)
						{
							case 1: result.colorsA[pos].r = val; break; //layer num already increased
							case 2: result.colorsA[pos].g = val; break;
							case 3: result.colorsA[pos].b = val; break;
							case 4: result.colorsA[pos].a = val; break;
							case 5: result.colorsB[pos].r = val; break;
							case 6: result.colorsB[pos].g = val; break;
							case 7: result.colorsB[pos].b = val; break;
							case 8: result.colorsB[pos].a = val; break;
						}
					}

					if (chunk.stop) return;
				}
			}

			/*//optimizing matrices list if they are not used
			for (int i=matrices.Count-1; i>=0; i--)
				if (opacities[i]<0.001f || matrices[i].IsEmpty() || (biomeMasks[i]!=null && biomeMasks[i].IsEmpty())) 
					{ prototypesList.RemoveAt(i); opacities.RemoveAt(i); matrices.RemoveAt(i); biomeMasks.RemoveAt(i); }*/

			//pushing to apply
			if (chunk.stop) return;
			chunk.apply.CheckAdd(typeof(RTPOutput), result, replace:true);

			//debug timer
			if (chunk.timer != null) 
			{ 
				chunk.timer.Stop(); 
				MapMagic.instance.guiDebugProcessTimes.CheckAdd(typeof(RTPOutput), chunk.timer.ElapsedMilliseconds, replace:true); 
				Debug.Log("RTP Process");
			}
		}

		static partial void _Apply (Chunk chunk)
		{
			if (rtp == null) rtp = MapMagic.instance.gameObject.GetComponent<ReliefTerrain>();
			if (rtp==null || rtp.globalSettingsHolder==null) return;
			
			//debug timer
			if (MapMagic.instance.guiDebug)
			{
				if (chunk.timer==null) chunk.timer = new System.Diagnostics.Stopwatch(); 
				else chunk.timer.Reset();
				chunk.timer.Start();
			}

			//guard if old-style rtp approach is used
			ReliefTerrain chunkRTP = chunk.terrain.gameObject.GetComponent<ReliefTerrain>();
			if (chunkRTP !=null && chunkRTP.enabled) 
			{
				Debug.Log("MapMagic: RTP component on terain chunk detected. RTP Output Generator works with one RTP script assigned to main MM object only. Make sure that Copy Components is turned off.");
				chunkRTP.enabled = false;
			}

			//loading objects
			RTPTuple tuple = (RTPTuple)chunk.apply[typeof(RTPOutput)];
			if (tuple==null) return;

			//creating control textures
			Texture2D controlA = new Texture2D(MapMagic.instance.resolution, MapMagic.instance.resolution);
			controlA.wrapMode = TextureWrapMode.Clamp;
			controlA.SetPixels(0,0,controlA.width,controlA.height,tuple.colorsA);
			controlA.Apply();

			Texture2D controlB = null;
			if (tuple.colorsB != null) 
			{
				controlB = new Texture2D(MapMagic.instance.resolution, MapMagic.instance.resolution);
				controlB.wrapMode = TextureWrapMode.Clamp;
				controlB.SetPixels(0,0,controlB.width,controlB.height,tuple.colorsB);
				controlB.Apply();
			}

			//welding
			Chunk chunkPrevX = MapMagic.instance.terrains[chunk.coord.x-1, chunk.coord.z]; 
			Chunk chunkNextX = MapMagic.instance.terrains[chunk.coord.x+1, chunk.coord.z]; 
			Chunk chunkPrevZ = MapMagic.instance.terrains[chunk.coord.x, chunk.coord.z-1]; 
			Chunk chunkNextZ = MapMagic.instance.terrains[chunk.coord.x, chunk.coord.z+1]; 

			Texture2D texturePrevX = (chunkPrevX!=null && chunkPrevX.complete && chunkPrevX.terrain.materialTemplate!=null && chunkPrevX.terrain.materialTemplate.shader.name=="Relief Pack/ReliefTerrain-FirstPass")? (Texture2D)chunkPrevX.terrain.materialTemplate.GetTexture("_Control1") : null;
			Texture2D textureNextX = (chunkNextX!=null && chunkNextX.complete && chunkNextX.terrain.materialTemplate!=null && chunkNextX.terrain.materialTemplate.shader.name=="Relief Pack/ReliefTerrain-FirstPass")? (Texture2D)chunkNextX.terrain.materialTemplate.GetTexture("_Control1") : null;
			Texture2D texturePrevZ = (chunkPrevZ!=null && chunkPrevZ.complete && chunkPrevZ.terrain.materialTemplate!=null && chunkPrevZ.terrain.materialTemplate.shader.name=="Relief Pack/ReliefTerrain-FirstPass")? (Texture2D)chunkPrevZ.terrain.materialTemplate.GetTexture("_Control1") : null;
			Texture2D textureNextZ = (chunkNextZ!=null && chunkNextZ.complete && chunkNextZ.terrain.materialTemplate!=null && chunkNextZ.terrain.materialTemplate.shader.name=="Relief Pack/ReliefTerrain-FirstPass")? (Texture2D)chunkNextZ.terrain.materialTemplate.GetTexture("_Control1") : null;

			WeldTerrains.WeldTexture(controlA, texturePrevX, textureNextZ, textureNextX, texturePrevZ, MapMagic.instance.splatsWeldMargins);

			if (controlB != null)
			{
				texturePrevX = (chunkPrevX!=null && chunkPrevX.complete && chunkPrevX.terrain.materialTemplate!=null && chunkPrevX.terrain.materialTemplate.shader.name=="Relief Pack/ReliefTerrain-FirstPass")? (Texture2D)chunkPrevX.terrain.materialTemplate.GetTexture("_Control2") : null;
				textureNextX = (chunkNextX!=null && chunkNextX.complete && chunkNextX.terrain.materialTemplate!=null && chunkNextX.terrain.materialTemplate.shader.name=="Relief Pack/ReliefTerrain-FirstPass")? (Texture2D)chunkNextX.terrain.materialTemplate.GetTexture("_Control2") : null;
				texturePrevZ = (chunkPrevZ!=null && chunkPrevZ.complete && chunkPrevZ.terrain.materialTemplate!=null && chunkPrevZ.terrain.materialTemplate.shader.name=="Relief Pack/ReliefTerrain-FirstPass")? (Texture2D)chunkPrevZ.terrain.materialTemplate.GetTexture("_Control2") : null;
				textureNextZ = (chunkNextZ!=null && chunkNextZ.complete && chunkNextZ.terrain.materialTemplate!=null && chunkNextZ.terrain.materialTemplate.shader.name=="Relief Pack/ReliefTerrain-FirstPass")? (Texture2D)chunkNextZ.terrain.materialTemplate.GetTexture("_Control2") : null;

				WeldTerrains.WeldTexture(controlB, texturePrevX, textureNextZ, textureNextX, texturePrevZ, MapMagic.instance.splatsWeldMargins);
			}

			//getting rtp material
			Material mat = null;
			if (chunk.terrain.materialTemplate!=null && chunk.terrain.materialTemplate.shader.name=="Relief Pack/ReliefTerrain-FirstPas")  //if relief terrain material assigned to terrain
				mat = chunk.terrain.materialTemplate;
			//if (mat==null && chunk.previewBackupMaterial!=null && chunk.previewBackupMaterial.shader.name=="Relief Pack/ReliefTerrain-FirstPas") //if it is backed up for preview
			//	mat = chunk.previewBackupMaterial;
			if (mat == null) //if still could not find material - creating new
			{
				Shader shader = Shader.Find("Relief Pack/ReliefTerrain-FirstPass");
				mat = new Material(shader);

				if (MapMagic.instance.previewOutput == null) chunk.terrain.materialTemplate = mat;
				//else chunk.previewBackupMaterial = mat;
			}
			chunk.terrain.materialType = Terrain.MaterialType.Custom;

			//setting
			rtp.RefreshTextures(mat);
			rtp.globalSettingsHolder.Refresh(mat, rtp);
			mat.SetTexture("_Control1", controlA);
			if (controlB!=null) { mat.SetTexture("_Control2", controlB); mat.SetTexture("_Control3", controlB); }

			//debug timer
			if (chunk.timer != null) 
			{ 
				chunk.timer.Stop(); 
				MapMagic.instance.guiDebugApplyTimes.CheckAdd(typeof(RTPOutput), chunk.timer.ElapsedMilliseconds, replace:true); 
				Debug.Log("RTP Applied");
			}
		}

		static partial void _Purge (Chunk chunk)
		{
			if (chunk.locked) return;

			SplatPrototype[] prototypes = new SplatPrototype[1];
			if (prototypes[0]==null) prototypes[0] = new SplatPrototype();
			if (prototypes[0].texture==null) prototypes[0].texture = defaultTex;
			chunk.terrain.terrainData.splatPrototypes = prototypes;
		
			float[,,] emptySplats = new float[16,16,1];
			for (int x=0; x<16; x++)
				for (int z=0; z<16; z++)
					emptySplats[z,x,0] = 1;

			chunk.terrain.terrainData.alphamapResolution = 16;
			chunk.terrain.terrainData.SetAlphamaps(0,0,emptySplats);

			if (MapMagic.instance.guiDebug) Debug.Log("Splats Purged");
		}

		partial void _OnGUI () 
		{
			if (rtp==null) rtp = MapMagic.instance.GetComponent<ReliefTerrain>();
			if (rtp==null) 
			{
				layout.Par(220);
				layout.Label("Could not find Relief Terrain component. Make sure you've performed the following steps: " +
					"\n\n- Remove or disable all of the Textures Outputs in the graph and biomes;" + 
					"\n\n- Add MeshRenderer (disabled), Relief Terrain and Instance Updater components to the MapMagic object;" + 
					"\n\n- Make sure Copy Components To Terrain feature in settings is disabled;" +
					"\n\n- Switch Terrain Material Type to RTP.",
					rect:layout.Inset(), helpbox: true, fontSize:8.5f);
				if (layout.Button("Perform All Automatically"))
				{	
					//instance updater
					MapMagic.instance.gameObject.AddComponent<InstantUpdater>();
					MapMagic.instance.terrainMaterialType = MapMagic.TerrainMaterialType.RTP;
					MapMagic.instance.copyComponents = false;

					MeshRenderer renderer = MapMagic.instance.gameObject.AddComponent<MeshRenderer>();
					renderer.enabled = false;
					rtp = MapMagic.instance.gameObject.AddComponent<ReliefTerrain>();

					//filling empty splats
					Texture2D emptyTex = Extensions.ColorTexture(4,4,new Color(0.5f, 0.5f, 0.5f, 1f));
					rtp.globalSettingsHolder.splats = new Texture2D[] { emptyTex,emptyTex,emptyTex,emptyTex };
				}
			}
			
			else
			{
				//refreshing layers from rtp
				Texture2D[] splats = rtp.globalSettingsHolder.splats;
				if (baseLayers.Length != splats.Length) baseLayers = new Layer[splats.Length];
				for (int i=0; i<baseLayers.Length; i++) 
				{ 
					if (baseLayers[i] == null) baseLayers[i] = new Layer();
					baseLayers[i].rtp = rtp; 
					baseLayers[i].num = i; 
					baseLayers[0].pinned = true;
				}
				
			
				layout.DrawLayered(this, "Layers:", selectable:false, drawButtons:false);

				layout.margin = 10; layout.rightMargin = 10;
				layout.Par(40); layout.Label("To add, remove or change layer order use Relief Terrain component.", rect:layout.Inset(), helpbox: true);
			}
		}

		/*public void RefreshRTP ()
		{
			if (rtp==null) rtp = MapMagic.instance.GetComponent<ReliefTerrain>();
			if (rtp==null) 
		}*/
	}

}